class PrefProfile {
  static String idUser = 'id_user';
  static String name = 'name';
  static String email = 'email';
  static String createAt = 'created_at';
}
