package com.example.home_production

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
